install.packages("ggplot2")
install.packages("dplyr")
install.packages("tidyverse")
install.packages("ggtern")
install.packages("robustbase")

install.packages("Rdonlp2", repos="http://R-Forge.R-project.org")
install.packages("doSNOW")
